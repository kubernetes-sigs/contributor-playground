# GopherCon Denver Playground Area

This directory is for Gophers in the 2018 Denver Gophercon to try out playing with Kubernetes repository automation.

Fork this repo, and try adding a file to this directory!


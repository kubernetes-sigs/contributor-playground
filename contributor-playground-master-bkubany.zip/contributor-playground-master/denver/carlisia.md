# About me

I think Kubernetes is dope.
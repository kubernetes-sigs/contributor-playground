Hello my name is Eddie Villalba

I live in Austin, TX and I currently work for Microsoft on the Azure Cloud Architect team for Cloud Native technologies including Azure Kubernetes Service, Helm, Draft and other Cloud Native technologies.

My twitter handle is @evill_genius and more than happy to hear from you all!

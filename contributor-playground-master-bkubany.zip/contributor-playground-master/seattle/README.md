# KubeCon Seattle 2018 New Kubernetes Contributor Workshop

This is the location of our Seattle New Contributor Worshop Pull Request activity.

[Follow this link to see a draft schedule outline](https://git.k8s.io/community/events/2018/12-contributor-summit)
and stay tuned for more information!

# KubeCon Shanghai 2018 New Kubernetes Contributor Workshop

This is the location of our Shanghai New Contributor Worshop Pull Request activity.

Fork this repo, and try adding files to this directory.
